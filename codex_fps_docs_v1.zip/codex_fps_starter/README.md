# 城市巷战 FPS · Codex 开发文档包 v1.0

> 状态：设计与实现合同（**并非已完成的 Godot 游戏**）。适用：Windows 单人 FPS、Godot 4.7.x（如项目机器版本不同，在 TASK-000 审核并锁定当前 4.x 稳定版本）、GDScript、离线开发。

## 先做什么
1. 将本包所有文件复制到**现有 Godot 工程根目录**（如果还没有工程，新建一个空目录并将本包置入）；不要覆盖已存在的 `AGENTS.md` / `docs` / `tasks`，先手工合并。
2. 初始化 Git，执行 `git status`，确认基线和未提交改动。引擎版本、项目状态、资源情况以实际检测为准。
3. 在 Codex 中打开项目根目录，把 `PROMPT_FIRST_RUN.md` 的文字发给 Codex，**只执行 TASK-000**。
4. TASK-000 验收后，按 `docs/08_ROADMAP.md` 顺序一次执行一张 TASK。每张任务结束检查验收记录、截图、运行日志及 Git diff。
5. 不要把这里的概念图误认为已存在的 GLB、角色骨骼或者可用动画。

## 文档索引（按执行优先级）
| 文件 | 职责 | 谁使用 |
|---|---|---|
| `AGENTS.md` | Codex 每次操作都遵守的红线与完成定义 | Codex 必读 |
| `docs/00_PRD.md` | 产品目标、范围、玩家体验、第一版完成定义 | 产品 + Codex |
| `docs/01_ARCHITECTURE.md` | Godot 场景树、模块边界、信号与数据约束 | Codex |
| `docs/02_LEVEL_DESIGN.md` | 80m 纵切片、5 区段路线和场景变化规则 | 关卡 + Codex |
| `docs/03_ASSET_PIPELINE.md` | 3D 拆分粒度、GLB/骨骼/材质/碰撞标准 | 建模 + Codex |
| `docs/04_GAMEPLAY.md` | 移动、武器、伤害、掩体、数值初稿 | Codex |
| `docs/05_AI.md` | 敌人状态机、生成约束和行为边界 | Codex |
| `docs/06_PRESENTATION.md` | HUD、音效、烟尘、爆炸表现及性能档位 | 美术 + Codex |
| `docs/07_QA_PERFORMANCE.md` | 自动化 + 实机验收用例、性能指标 | QA + Codex |
| `docs/08_ROADMAP.md` | 小任务顺序、里程碑和停工条件 | 项目管理 |
| `docs/09_DECISIONS_RISKS.md` | 已确定与未确定事项、易踩的坑 | 全员 |
| `tasks/TASK-*.md` | 一次交给 Codex 的独立、可验收任务 | Codex |
| `data/vertical_slice.json` | 80 米切片的数据示例（不是游戏资源） | Codex |
| `data/asset_registry.json` | 资产槽位合同（并不意味着文件已经存在） | Codex |
| `templates/TASK_TEMPLATE.md` | 未来扩展任务的标准格式 | 你 / Codex |
| `scripts/validate_docs.py` | 文档/JSON 的基础一致性检查 | 本地 |

## 两条推荐路径
- **已有 Godot 工程**：保留原有项目、检查兼容性，在分支上开发，严禁清空重建。TASK-000 先审计，再进行最小改动。
- **空目录新项目**：TASK-000 创建可打开的 Godot 项目及灰盒测试场景。

## 核心原则
**先能玩再写实；先 80 米战斗切片再扩展 500 米；先占位资源再替换 GLB；先验证再进入下一任务。**

## 本包不提供的东西
- 不包括已绑定骨骼的敌人模型、动作动画、武器模型、PBR 材质贴图或爆炸音效的商用授权。
- 不包含可运行游戏项目、实际 FPS 性能测量结果或 Codex 执行结果。必须由你的本地 Godot + Codex 开发验证。

## 资料依据
- Codex `AGENTS.md`：https://learn.chatgpt.com/docs/agent-configuration/agents-md
- Codex 最佳实践：https://learn.chatgpt.com/docs/learn/best-practices
- Godot 4.7 及支持策略：https://docs.godotengine.org/en/stable/about/release_policy.html
- Godot GridMap：https://docs.godotengine.org/en/stable/tutorials/3d/using_gridmaps.html
